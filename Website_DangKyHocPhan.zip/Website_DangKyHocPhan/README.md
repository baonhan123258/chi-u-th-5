# Hướng dẫn cài đặt
1. Import `database.sql` vào SQL Server.
2. Cấu hình `config.php` với thông tin SQL Server.
3. Chạy backend bằng XAMPP và frontend qua trình duyệt.