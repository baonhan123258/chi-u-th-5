<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $maSV = $_POST['MaSV'];
    $maHP = $_POST['MaHP'];
    $sql = "INSERT INTO DangKy (NgayDK, MaSV) VALUES (GETDATE(), ?)";
    $params = [$maSV];
    sqlsrv_query($conn, $sql, $params);
    echo json_encode(["message" => "Đăng ký thành công"]);
    exit;
}
sqlsrv_close($conn);
?>