<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM Users WHERE Username = ? AND Password = ?";
    $params = [$username, $password];
    $stmt = sqlsrv_query($conn, $sql, $params);
    if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo json_encode(["message" => "Đăng nhập thành công", "user" => $row]);
    } else {
        echo json_encode(["error" => "Sai tên đăng nhập hoặc mật khẩu"]);
    }
    exit;
}
sqlsrv_close($conn);
?>