<?php
$serverName = "localhost";
$connectionOptions = array(
    "Database" => "Test1",
    "Uid" => "sa",
    "PWD" => "your_password"
);
$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>