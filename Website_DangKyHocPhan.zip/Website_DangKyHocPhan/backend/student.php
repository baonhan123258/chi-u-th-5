<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM SinhVien";
    $stmt = sqlsrv_query($conn, $sql);
    $students = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $students[] = $row;
    }
    echo json_encode($students);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $maSV = $_POST['MaSV'];
    $hoTen = $_POST['HoTen'];
    $gioiTinh = $_POST['GioiTinh'];
    $ngaySinh = $_POST['NgaySinh'];
    $sql = "INSERT INTO SinhVien (MaSV, HoTen, GioiTinh, NgaySinh) VALUES (?, ?, ?, ?)";
    $params = [$maSV, $hoTen, $gioiTinh, $ngaySinh];
    sqlsrv_query($conn, $sql, $params);
    echo json_encode(["message" => "Thêm sinh viên thành công"]);
    exit;
}

sqlsrv_close($conn);
?>