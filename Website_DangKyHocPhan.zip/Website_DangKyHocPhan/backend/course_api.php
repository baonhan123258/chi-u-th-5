<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM HocPhan";
    $stmt = sqlsrv_query($conn, $sql);
    $courses = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $courses[] = $row;
    }
    echo json_encode($courses);
    exit;
}
sqlsrv_close($conn);
?>